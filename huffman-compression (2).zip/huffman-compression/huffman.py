"""File compression using Huffman Coding.

Usage:
    python huffman.py compress   input.txt output.huf
    python huffman.py decompress output.huf restored.txt
    python huffman.py stats      input.txt
"""
import heapq
import os
import struct
import sys
from collections import Counter

MAGIC = b"HUF1"


class Node:
    """Node of the Huffman tree. Leaves hold a byte value in `symbol`."""

    def __init__(self, freq, symbol=None, left=None, right=None):
        self.freq = freq
        self.symbol = symbol
        self.left = left
        self.right = right

    def is_leaf(self):
        return self.left is None and self.right is None


def build_frequency_table(data: bytes) -> dict:
    """Step 1: count how often each byte occurs. O(N)."""
    return dict(Counter(data))


def build_huffman_tree(freqs: dict):
    """Step 2: build the Huffman tree with a min-heap. O(n log n).

    A running counter breaks frequency ties so the tree is deterministic,
    which lets the decoder rebuild the exact same tree from the table.
    """
    if not freqs:
        return None
    heap, order = [], 0
    for symbol in sorted(freqs):
        heap.append((freqs[symbol], order, Node(freqs[symbol], symbol)))
        order += 1
    heapq.heapify(heap)
    while len(heap) > 1:
        f1, _, left = heapq.heappop(heap)
        f2, _, right = heapq.heappop(heap)
        heapq.heappush(heap, (f1 + f2, order, Node(f1 + f2, None, left, right)))
        order += 1
    return heap[0][2]


def generate_codes(root) -> dict:
    """Step 3: walk the tree; left edge = '0', right edge = '1'. O(n)."""
    codes = {}
    if root is None:
        return codes
    if root.is_leaf():  # only one distinct symbol
        codes[root.symbol] = "0"
        return codes
    stack = [(root, "")]
    while stack:
        node, prefix = stack.pop()
        if node.is_leaf():
            codes[node.symbol] = prefix
        else:
            stack.append((node.right, prefix + "1"))
            stack.append((node.left, prefix + "0"))
    return codes


def encode(data: bytes, codes: dict) -> tuple:
    """Step 4: replace each byte by its code. Returns (packed bytes, padding bits)."""
    bits = "".join(codes[b] for b in data)
    padding = (8 - len(bits) % 8) % 8
    bits += "0" * padding
    packed = bytearray(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8))
    return bytes(packed), padding


def decode(packed: bytes, padding: int, root, original_length: int) -> bytes:
    """Step 5: walk the tree bit by bit to recover the original bytes."""
    if root is None or original_length == 0:
        return b""
    if root.is_leaf():
        return bytes([root.symbol]) * original_length
    out = bytearray()
    node = root
    for byte in packed:
        for bit in format(byte, "08b"):
            node = node.right if bit == "1" else node.left
            if node.is_leaf():
                out.append(node.symbol)
                node = root
                if len(out) == original_length:
                    return bytes(out)
    return bytes(out)


# ---- container format -------------------------------------------------
# MAGIC(4) | original_length(8) | padding(1) | table_size(2) |
# table_size x [symbol(1) + count(4)] | packed data

def compress_bytes(data: bytes) -> bytes:
    freqs = build_frequency_table(data)
    root = build_huffman_tree(freqs)
    codes = generate_codes(root)
    packed, padding = encode(data, codes)
    header = MAGIC + struct.pack(">QBH", len(data), padding, len(freqs))
    table = b"".join(struct.pack(">BI", s, freqs[s]) for s in sorted(freqs))
    return header + table + packed


def decompress_bytes(blob: bytes) -> bytes:
    if blob[:4] != MAGIC:
        raise ValueError("Not a valid .huf file")
    length, padding, table_size = struct.unpack(">QBH", blob[4:15])
    pos = 15
    freqs = {}
    for _ in range(table_size):
        symbol, count = struct.unpack(">BI", blob[pos:pos + 5])
        freqs[symbol] = count
        pos += 5
    root = build_huffman_tree(freqs)
    return decode(blob[pos:], padding, root, length)


def compress_file(src: str, dst: str) -> None:
    with open(src, "rb") as f:
        data = f.read()
    with open(dst, "wb") as f:
        f.write(compress_bytes(data))


def decompress_file(src: str, dst: str) -> None:
    with open(src, "rb") as f:
        blob = f.read()
    with open(dst, "wb") as f:
        f.write(decompress_bytes(blob))


def report(src: str) -> None:
    """Print frequencies, codes, and original vs compressed size."""
    with open(src, "rb") as f:
        data = f.read()
    freqs = build_frequency_table(data)
    codes = generate_codes(build_huffman_tree(freqs))
    compressed = compress_bytes(data)
    payload_bits = sum(freqs[s] * len(codes[s]) for s in freqs)

    print(f"{'Char':<6}{'Freq':>8}  Code")
    for s in sorted(freqs, key=lambda s: (-freqs[s], s)):
        ch = repr(chr(s)) if 32 <= s < 127 or s in (9, 10) else f"0x{s:02x}"
        print(f"{ch:<6}{freqs[s]:>8}  {codes[s]}")
    orig, comp = len(data), len(compressed)
    print(f"\nOriginal size    : {orig} bytes")
    print(f"Encoded payload  : {(payload_bits + 7) // 8} bytes")
    print(f"Compressed file  : {comp} bytes (includes {15 + 5 * len(freqs)}-byte header)")
    if orig:
        print(f"Ratio            : {comp / orig:.2%} of original "
              f"({(1 - comp / orig):.2%} saved)")


def main(argv):
    usage = __doc__
    if len(argv) < 3:
        print(usage)
        return 1
    cmd = argv[1]
    if cmd == "compress" and len(argv) == 4:
        compress_file(argv[2], argv[3])
        print(f"{argv[2]} ({os.path.getsize(argv[2])} B) -> "
              f"{argv[3]} ({os.path.getsize(argv[3])} B)")
    elif cmd == "decompress" and len(argv) == 4:
        decompress_file(argv[2], argv[3])
        print(f"{argv[2]} -> {argv[3]} ({os.path.getsize(argv[3])} B)")
    elif cmd == "stats" and len(argv) == 3:
        report(argv[2])
    else:
        print(usage)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
