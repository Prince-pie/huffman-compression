# File Compression Using Huffman Coding

A lossless text-file compressor built on Huffman Coding, written in pure Python (no dependencies).

## Problem Statement
Reduce the storage space required for text files by:
1. calculating character frequencies,
2. constructing a Huffman Tree,
3. generating binary codes,
4. encoding and decoding,
5. analysing time and space complexity and comparing original vs. compressed file sizes.

## How It Works
| Step | Function | Idea |
|------|----------|------|
| 1 | `build_frequency_table` | Count each byte with `Counter` |
| 2 | `build_huffman_tree` | Repeatedly merge the two lowest-frequency nodes using a min-heap |
| 3 | `generate_codes` | Left edge = `0`, right edge = `1`; leaf path = code |
| 4 | `encode` | Replace every byte by its code, pack bits into bytes, pad the last byte |
| 5 | `decode` | Walk the tree bit by bit; emit a symbol at each leaf |

Frequent characters get short codes and rare characters get long ones. No code is a prefix of another, so decoding is unambiguous.

The tree is built on bytes, so any UTF-8 text (including Hindi, emoji, etc.) works. Ties in frequency are broken deterministically, so the decoder rebuilds the identical tree from the stored frequency table.

### Compressed file format
```
MAGIC "HUF1" (4) | original length (8) | padding bits (1) | table size (2)
| table: [symbol (1) + count (4)] x n | packed bit data
```

## Usage
```bash
python huffman.py compress   sample.txt sample.huf
python huffman.py decompress sample.huf restored.txt
python huffman.py stats      sample.txt      # frequencies, codes, size comparison
```

## Run the Tests
```bash
python -m unittest -v
```
Covers empty input, single character, single distinct symbol, Unicode, all 256 byte values, prefix-free property, shorter codes for frequent symbols, file round-trip, and invalid input.

## Sample Result (`sample.txt`)
| | Size |
|---|---|
| Original | 14,680 bytes |
| Compressed (incl. 170-byte header) | 7,920 bytes |
| Saved | 46.05% |

## Complexity Analysis
Let **N** = number of bytes in the file and **n** = number of distinct symbols (n <= 256).

| Phase | Time | Space |
|-------|------|-------|
| Frequency count | O(N) | O(n) |
| Build tree (min-heap) | O(n log n) | O(n) |
| Generate codes | O(n) | O(n) |
| Encode | O(N) | O(N) for the bit string |
| Decode | O(N) | O(N) output |
| **Overall** | **O(N + n log n)** | **O(N + n)** |

Since n is at most 256, tree building is effectively constant, so total time is dominated by O(N).

## Limitations
- Very small files may not shrink, because the frequency-table header costs 5 bytes per distinct symbol.
- Files with near-uniform byte frequencies (already compressed or random data) gain little.
- Encoding uses a Python bit string for clarity rather than maximum speed.

## Project Structure
```
huffman-compression/
├── huffman.py        # algorithm + CLI
├── test_huffman.py   # unit tests
├── sample.txt        # demo input
├── README.md
└── .gitignore
```
