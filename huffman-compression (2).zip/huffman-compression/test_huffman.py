import os
import tempfile
import unittest

import huffman as h


class HuffmanTests(unittest.TestCase):
    def roundtrip(self, data: bytes):
        self.assertEqual(h.decompress_bytes(h.compress_bytes(data)), data)

    def test_normal_text(self):
        self.roundtrip(b"abracadabra alakazam")

    def test_empty(self):
        self.roundtrip(b"")

    def test_single_symbol(self):
        self.roundtrip(b"aaaaaaaa")

    def test_one_character(self):
        self.roundtrip(b"a")

    def test_unicode(self):
        self.roundtrip("नमस्ते दुनिया — héllo wörld ✓".encode("utf-8"))

    def test_all_byte_values(self):
        self.roundtrip(bytes(range(256)) * 3)

    def test_prefix_free(self):
        codes = h.generate_codes(h.build_huffman_tree(h.build_frequency_table(b"mississippi river")))
        vals = list(codes.values())
        for i, a in enumerate(vals):
            for j, b in enumerate(vals):
                if i != j:
                    self.assertFalse(b.startswith(a))

    def test_frequent_symbols_get_shorter_codes(self):
        data = b"a" * 100 + b"b" * 10 + b"c"
        codes = h.generate_codes(h.build_huffman_tree(h.build_frequency_table(data)))
        self.assertLessEqual(len(codes[ord("a")]), len(codes[ord("b")]))
        self.assertLessEqual(len(codes[ord("b")]), len(codes[ord("c")]))

    def test_compresses_repetitive_text(self):
        data = b"the quick brown fox jumps over the lazy dog. " * 200
        self.assertLess(len(h.compress_bytes(data)), len(data))

    def test_file_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            src, mid, out = (os.path.join(d, n) for n in ("a.txt", "a.huf", "b.txt"))
            with open(src, "wb") as f:
                f.write(b"hello huffman " * 50)
            h.compress_file(src, mid)
            h.decompress_file(mid, out)
            with open(src, "rb") as a, open(out, "rb") as b:
                self.assertEqual(a.read(), b.read())

    def test_invalid_file(self):
        with self.assertRaises(ValueError):
            h.decompress_bytes(b"NOPE" + b"\x00" * 20)


if __name__ == "__main__":
    unittest.main()
